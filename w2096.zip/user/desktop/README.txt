Welcome to Windows 2096 V1!

This Windows 96 modification is themed to look like Windows 2000 and features the following:

- Windows 2000 icons
- Windows 2000 wallpapers
- Partially stripped down

CREDITS:
Kelbaz for the Mikesoft logo on the About UI
shiypc for the classic Control Panel

Please note: some icons are only for decoration and do not work. (Search, Show Desktop and Outlook Express)

Modification by theblueguy