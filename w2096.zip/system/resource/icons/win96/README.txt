Windows 96 Default Icon Theme
-----------------------------
Some icons (C) Microsoft Corporation

A number of icons are authored by us, even some which are designed to look like the 9x style.
Windows icons (C) Microsoft Corporation.
Any other icons are (C) mikesoft collective 2022 and their respective owners (even if no explicit copyright mention was made of said owners)

