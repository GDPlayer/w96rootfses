Welcome to Windows 96!

Files stored in C:/ stay on your computer and DO NOT get uploaded to our server!
Make periodic backups since in case of instability/crashes.

*** FS Paths ***
 system/           - The system folder.
                     Contains all system bins, start menu items, and other various system files.

 system/boot       - The boot folder.
                     Contains scripts, wasm, and CSS files to apply at boot.

 system/boot/apps  - The apps folder.
                     Contains installed apps.
			
 trash/            - The recycle bin.
                     Contains deleted files.
			
 user/             - Your user folder.
                     Contains all your user data and remains mostly untouched during version upgrades.
					 
 local/            - App data files folder.
                     Contains all the data files for installed apps. Think of it as program files.
			
*** Diagnosing Problems ***
To fix any issues that may occur in your session, simply restart. This is the easiest fix by far and solves many issues.

If you are experiencing glitches and unexplained crashes, you can try to reinstall your system.
To do this, go to Start > Reinstall or simply delete the system folder.

Should bugs still persist, please report them at http://bug.windows96.net